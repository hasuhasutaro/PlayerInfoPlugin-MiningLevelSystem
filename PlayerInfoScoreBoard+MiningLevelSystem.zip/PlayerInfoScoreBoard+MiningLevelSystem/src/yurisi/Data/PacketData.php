<?php

namespace yurisi\Data;

interface PacketData{
	const D_S="sidebar";
	const C_N="dummy";
}